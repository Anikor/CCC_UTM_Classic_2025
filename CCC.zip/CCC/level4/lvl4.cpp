from collections import deque

def get_adjacent_paces(current_pace):
    """Get valid next paces from current pace"""
    pace_order = [-1, -2, -3, -4, -5, 0, 5, 4, 3, 2, 1]
    try:
        idx = pace_order.index(current_pace)
        neighbors = []
        if idx > 0:
            neighbors.append(pace_order[idx - 1])
        if idx < len(pace_order) - 1:
            neighbors.append(pace_order[idx + 1])
        return neighbors
    except ValueError:
        return []

def find_sequence_bfs(target_nonzero, direction, max_cost):
    """
    Find a pace sequence matching the constraints.
    Uses BFS to explore all valid sequences.
    """
    queue = deque([(0, 0, 0, 0, [0])])
    visited = set()
    
    max_iterations = 1000000
    iterations = 0
    
    while queue and iterations < max_iterations:
        iterations += 1
        current_pace, position, nonzero_count, cost, path = queue.popleft()
        
        # Check if we found a solution
        if current_pace == 0 and len(path) > 1:
            if nonzero_count == abs(target_nonzero):
                if (direction > 0 and position > 0) or (direction < 0 and position < 0):
                    if cost == max_cost:
                        return path
        
        # Pruning
        state = (current_pace, position, nonzero_count, cost)
        if state in visited:
            continue
        visited.add(state)
        
        if len(path) > 100 or cost > max_cost or nonzero_count > abs(target_nonzero):
            continue
        
        # Option 1: Stay at current pace (if not 0)
        if current_pace != 0:
            new_pos = position + current_pace
            new_cost = cost + abs(new_pos)
            new_nonzero = nonzero_count + 1
            new_path = path + [current_pace]
            queue.append((current_pace, new_pos, new_nonzero, new_cost, new_path))
        
        # Option 2: Change pace to adjacent value
        for next_pace in get_adjacent_paces(current_pace):
            new_pos = position + next_pace
            new_cost = cost + abs(new_pos)
            new_nonzero = nonzero_count + (1 if next_pace != 0 else 0)
            new_path = path + [next_pace]
            queue.append((next_pace, new_pos, new_nonzero, new_cost, new_path))
    
    return None

# Solve all test cases
def solve_all(test_cases):
    """Solve all test cases and return formatted output"""
    results = []
    for target, cost in test_cases:
        direction = 1 if target > 0 else -1
        sequence = find_sequence_bfs(target, direction, cost)
        if sequence:
            results.append(' '.join(map(str, sequence)))
        else:
            results.append("No solution found")
    return results
