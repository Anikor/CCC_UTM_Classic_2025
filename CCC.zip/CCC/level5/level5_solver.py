#!/usr/bin/env python3
"""
LEVEL 5 - Asteroid Avoidance - Solution Generator

Goal:
  For each case:
    - Start at (0,0)
    - Reach station (sx, sy)
    - Avoid asteroid at (ax, ay) with safety square: |x-ax|<=2 and |y-ay|<=2
    - Stay within given time limit T
We don't need *perfect* optimality for the contest, just valid and reasonably short paths.
"""

from functools import lru_cache

MIN_PACE = 5
MAX_PACE = 1

# --------------------- 1D movement primitives --------------------- #

def cost1D(p):
    return 1 if p == 0 else abs(p)

def get_valid_paces(pace):
    """Exactly the same transition rules as in the visualizer."""
    if pace == -MIN_PACE:
        return [pace + 1, pace, 0]
    elif pace == -MAX_PACE:
        return [pace, pace - 1]
    elif pace == 0:
        return [-MIN_PACE, pace, MIN_PACE]
    elif pace == MAX_PACE:
        return [pace + 1, pace]
    elif pace == MIN_PACE:
        return [0, pace, pace - 1]
    else:
        return [pace + 1, pace, pace - 1]

def expand_paces(paces):
    """
    Expand paces to per-tick velocities: each non-zero pace p repeated |p| times,
    0 repeated once. Matches the visualization logic.
    """
    out = []
    for p in paces:
        c = max(1, abs(p))
        out.extend([p] * c)
    return out

def simulate_1d_distance(paces):
    """
    Given a sequence of paces (coarse), return how many grid cells we move in 1D,
    starting from position 0 and velocity 0.
    """
    pos = 0
    v = 0
    ticks = 0
    for p in expand_paces(paces):
        v = p
        if abs(v) > 0 and abs(v) <= MIN_PACE:
            ticks += 1
            if ticks >= abs(v):
                ticks = 0
                pos += 1 if v > 0 else -1
    return pos

# --------------------- Precomputed “nice” 1D patterns --------------------- #

# Optimal / very good patterns for small distances 1..8 (start 0, end 0, only forward).
BEST_SMALL = {
    1: ([0, 5, 0], 7),
    2: ([0, 5, 5, 0], 12),
    3: ([0, 5, 4, 5, 0], 16),
    4: ([0, 5, 4, 4, 5, 0], 20),
    5: ([0, 5, 4, 3, 4, 5, 0], 23),
    6: ([0, 5, 4, 3, 3, 4, 5, 0], 26),
    7: ([0, 5, 4, 3, 2, 3, 4, 5, 0], 28),
    8: ([0, 5, 4, 3, 2, 2, 3, 4, 5, 0], 30),
}

def make_family_pattern(k):
    """
    Pattern family described in the PDF:
      0, 5, 4, 3, 2, 1, 1,1,...(k times)...,1, 2,3,4,5, 0
    This gives a wide range of distances, with decent times.
    """
    return [0, 5, 4, 3, 2, 1] + [1]*k + [2,3,4,5,0]

# Build mapping: distance -> best pattern in that family.
FAMILY_PATTERNS = {}
for k in range(0, 150):
    pat = make_family_pattern(k)
    dist = simulate_1d_distance(pat)
    if dist <= 0:
        continue
    T = sum(cost1D(p) for p in pat)
    prev = FAMILY_PATTERNS.get(dist)
    if prev is None or T < prev[1]:
        FAMILY_PATTERNS[dist] = (pat, T)

# Ensure we have a good block for distance 48
if 48 not in FAMILY_PATTERNS:
    for k in range(0, 300):
        pat = make_family_pattern(k)
        if simulate_1d_distance(pat) == 48:
            FAMILY_PATTERNS[48] = (pat, sum(cost1D(p) for p in pat))
            break

PAT48, T48 = FAMILY_PATTERNS[48]

@lru_cache(maxsize=None)
def pattern_for_distance(D):
    """
    Get a 1D pattern (start 0, end 0, forward only) that moves distance D >= 0.
    Returns (paces, timeTicks).
    """
    if D == 0:
        return [0], 1
    if D < 0:
        raise ValueError("Pattern_for_distance expects non-negative D")

    if 1 <= D <= 8:
        pat, T = BEST_SMALL[D]
        return pat[:], T

    if D in FAMILY_PATTERNS:
        pat, T = FAMILY_PATTERNS[D]
        return pat[:], T

    # For bigger D or missing ones: compose from 48-blocks + remainder.
    q, r = divmod(D, 48)
    p = []
    T = 0

    for i in range(q):
        block_pat, block_T = PAT48, T48
        if i == 0:
            p.extend(block_pat)
        else:
            # avoid double 0 between blocks
            p.extend(block_pat[1:])
        T += block_T

    if r > 0:
        rem_pat, rem_T = pattern_for_distance(r)
        p.extend(rem_pat[1:])  # avoid extra 0 at join
        T += rem_T

    return p, T

def signed_pattern(D):
    """
    Pattern for possibly negative distance D.
    Uses forward pattern_for_distance, then flips sign of non-zero paces if D < 0.
    """
    if D == 0:
        return [0]
    sign = 1 if D > 0 else -1
    base, _ = pattern_for_distance(abs(D))
    if sign == 1:
        return base[:]
    return [sign * abs(p) for p in base]

# --------------------- Full 2D simulation & collision checking --------------------- #

def simulate_case(sx, sy, ax, ay, time_limit, px, py):
    """
    Check if given 1D pace sequences px, py are valid:
      - each sequence obeys pace transition rules
      - start and end with 0 pace
      - we stay within time_limit
      - we never enter the asteroid safety square (|x-ax|<=2, |y-ay|<=2)
      - we end exactly at (sx, sy)
    """
    # Basic check: start/end with 0
    if px[0] != 0 or py[0] != 0 or px[-1] != 0 or py[-1] != 0:
        return False

    # All paces in allowed range
    for seq in (px, py):
        for p in seq:
            if p < -MIN_PACE or p > MIN_PACE:
                return False

    # Pace transitions
    for seq in (px, py):
        last = seq[0]
        for p in seq[1:]:
            if p not in get_valid_paces(last):
                return False
            last = p

    # Expand to per-tick velocities
    ex = expand_paces(px)
    ey = expand_paces(py)

    # Pad to same tick count
    if len(ex) < len(ey):
        ex += [0] * (len(ey) - len(ex))
    elif len(ey) < len(ex):
        ey += [0] * (len(ex) - len(ey))

    ticks_total = len(ex)
    if ticks_total > time_limit:
        return False

    # Simulate positions
    x = y = 0
    vx = vy = 0
    tick_x = tick_y = 0

    for i in range(ticks_total):
        vx = ex[i]
        vy = ey[i]

        if abs(vx) > 0 and abs(vx) <= MIN_PACE:
            tick_x += 1
            if tick_x >= abs(vx):
                tick_x = 0
                x += 1 if vx > 0 else -1

        if abs(vy) > 0 and abs(vy) <= MIN_PACE:
            tick_y += 1
            if tick_y >= abs(vy):
                tick_y = 0
                y += 1 if vy > 0 else -1

        # asteroid safety square: 5x5 centered on asteroid
        if abs(x - ax) <= 2 and abs(y - ay) <= 2:
            return False

    # Must end at station
    return x == sx and y == sy

# --------------------- Path construction strategy --------------------- #

def build_path(sx, sy, ax, ay, time_limit):
    """
    Build a path with a simple shape:
      vertical from (0,0) to (0, Y1),
      then horizontal from (0,Y1) to (sx,Y1),
      then vertical from (sx,Y1) to (sx,sy).

    We'll try several Y1 (“detour levels”) and pick the first that avoids the asteroid.
    This keeps paths simple and relatively short.
    """
    candidates_Y = []

    # Straight L-shape (no detour)
    candidates_Y.append(sy)

    # Detours above/below asteroid
    det = 10
    candidates_Y.append(ay + det)
    candidates_Y.append(ay - det)
    candidates_Y.append(ay + 2*det)
    candidates_Y.append(ay - 2*det)

    # Also around origin a bit
    candidates_Y.append(0)
    candidates_Y.append(sy + 2*det)
    candidates_Y.append(sy - 2*det)

    # Remove duplicates and limit range to keep patterns reasonable
    seen = set()
    Ylist = []
    for Y1 in candidates_Y:
        if Y1 not in seen and abs(Y1) <= 400:
            seen.add(Y1)
            Ylist.append(Y1)

    for Y1 in Ylist:
        # Segments:
        # 1) (0,0)   -> (0, Y1)
        # 2) (0,Y1)  -> (sx, Y1)
        # 3) (sx,Y1) -> (sx, sy)
        D1 = Y1
        D2 = sx
        D3 = sy - Y1

        py1 = signed_pattern(D1)
        px1 = [0] * len(py1)

        px2 = signed_pattern(D2)
        py2 = [0] * len(px2)

        py3 = signed_pattern(D3)
        px3 = [0] * len(py3)

        px = px1 + px2 + px3
        py = py1 + py2 + py3

        if simulate_case(sx, sy, ax, ay, time_limit, px, py):
            return px, py

    # Fallback: if everything fails (rare), do simple straight path ignoring asteroid.
    # This at least keeps the file non-empty; you can tweak detours if needed.
    px = signed_pattern(sx)
    py = signed_pattern(sy)
    return px, py

# --------------------- IO helpers --------------------- #

def process_file(in_name, out_name):
    with open(in_name, "r") as f:
        lines = [line.strip() for line in f if line.strip()]

    n = int(lines[0])
    idx = 1
    outputs = []
    bad_cases = []

    for case_idx in range(1, n+1):
        sxsyT = lines[idx]; idx += 1
        axay  = lines[idx]; idx += 1

        sxsy, T_str = sxsyT.split()
        sx_str, sy_str = sxsy.split(',')
        sx = int(sx_str)
        sy = int(sy_str)
        T  = int(T_str)

        ax_str, ay_str = axay.split(',')
        ax = int(ax_str)
        ay = int(ay_str)

        px, py = build_path(sx, sy, ax, ay, T)

        if not simulate_case(sx, sy, ax, ay, T, px, py):
            bad_cases.append(case_idx)

        outputs.append(" ".join(str(p) for p in px))
        outputs.append(" ".join(str(p) for p in py))
        outputs.append("")  # blank line

        if case_idx % 100 == 0:
            print(f"  Progress: {case_idx}/{n}...")

    with open(out_name, "w") as f:
        f.write("\n".join(outputs).rstrip() + "\n")

    if bad_cases:
        print(f"⚠ Warning: {len(bad_cases)} cases failed internal check: {bad_cases[:10]}...")
    else:
        print(f"✓ Completed: {n}/{n} successful")
    print(f"✓ Saved: {out_name}")

# --------------------- main --------------------- #

def main():
    print("="*70)
    print("LEVEL 5 - SOLUTION GENERATOR")
    print("="*70)

    # small file
    print("Processing small file...")
    process_file("level5_1_small.in", "level5_1_small.out")
    print()

    # large file
    print("Processing large file...")
    process_file("level5_2_large.in", "level5_2_large.out")
    print()

    print("="*70)
    print("DONE! Check the .out files")
    print("="*70)

if __name__ == "__main__":
    main()
