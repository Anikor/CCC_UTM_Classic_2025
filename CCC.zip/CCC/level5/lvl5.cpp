#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <map>
#include <tuple>
#include <cmath>
#include <algorithm>
#include <string>

using namespace std;

// State: (x, y, vx, vy)
struct State {
    int x, y, vx, vy;

    bool operator<(const State& other) const {
        if (x != other.x) return x < other.x;
        if (y != other.y) return y < other.y;
        if (vx != other.vx) return vx < other.vx;
        return vy < other.vy;
    }
};

// Priority queue node
struct Node {
    int priority;
    int time;
    State state;
    vector<int> acc_x_history;
    vector<int> acc_y_history;

    bool operator>(const Node& other) const {
        return priority > other.priority;
    }
};

// Check if position is safe from asteroid (Chebyshev distance > 2)
bool isSafe(int x, int y, int ax, int ay) {
    return max(abs(x - ax), abs(y - ay)) > 2;
}

// Manhattan distance heuristic
int manhattanDistance(int x1, int y1, int x2, int y2) {
    return abs(x1 - x2) + abs(y1 - y2);
}

// A* search to find path
pair<vector<int>, vector<int>> solveCase(int target_x, int target_y, int time_limit, 
                                          int asteroid_x, int asteroid_y) {

    State start = {0, 0, 0, 0};

    priority_queue<Node, vector<Node>, greater<Node>> pq;
    map<State, int> visited;  // state -> best time

    Node startNode;
    startNode.priority = 0;
    startNode.time = 0;
    startNode.state = start;
    pq.push(startNode);

    int iterations = 0;
    const int MAX_ITERATIONS = 500000;

    while (!pq.empty() && iterations < MAX_ITERATIONS) {
        iterations++;

        Node current = pq.top();
        pq.pop();

        int x = current.state.x;
        int y = current.state.y;
        int vx = current.state.vx;
        int vy = current.state.vy;
        int t = current.time;

        // Goal check
        if (x == target_x && y == target_y && vx == 0 && vy == 0) {
            return {current.acc_x_history, current.acc_y_history};
        }

        // Time limit check
        if (t >= time_limit) continue;

        // Skip if we've seen this state with better or equal time
        if (visited.count(current.state) && visited[current.state] <= t) {
            continue;
        }
        visited[current.state] = t;

        // Try all accelerations from -5 to 5
        for (int ax = -5; ax <= 5; ax++) {
            for (int ay = -5; ay <= 5; ay++) {
                int new_vx = vx + ax;
                int new_vy = vy + ay;
                int new_x = x + new_vx;
                int new_y = y + new_vy;

                // Safety check
                if (!isSafe(new_x, new_y, asteroid_x, asteroid_y)) {
                    continue;
                }

                // Calculate heuristic
                int h = manhattanDistance(new_x, new_y, target_x, target_y) + 
                        abs(new_vx) + abs(new_vy);

                Node newNode;
                newNode.priority = t + 1 + h;
                newNode.time = t + 1;
                newNode.state = {new_x, new_y, new_vx, new_vy};
                newNode.acc_x_history = current.acc_x_history;
                newNode.acc_x_history.push_back(ax);
                newNode.acc_y_history = current.acc_y_history;
                newNode.acc_y_history.push_back(ay);

                pq.push(newNode);
            }
        }
    }

    // No solution found
    return {{0}, {0}};
}

int main(int argc, char* argv[]) {
    // Input/output file names
    string input_file = "input.in";
    string output_file = "output.out";

    if (argc >= 2) {
        input_file = argv[1];
    }
    if (argc >= 3) {
        output_file = argv[2];
    }

    ifstream infile(input_file);
    if (!infile.is_open()) {
        cerr << "Error: Could not open input file: " << input_file << endl;
        return 1;
    }

    ofstream outfile(output_file);
    if (!outfile.is_open()) {
        cerr << "Error: Could not open output file: " << output_file << endl;
        return 1;
    }

    int n;
    infile >> n;

    cout << "Solving " << n << " cases..." << endl;

    for (int i = 0; i < n; i++) {
        // Read station coordinates and time limit
        int target_x, target_y, time_limit;
        char comma;
        infile >> target_x >> comma >> target_y >> time_limit;

        // Read asteroid coordinates
        int asteroid_x, asteroid_y;
        infile >> asteroid_x >> comma >> asteroid_y;

        if ((i + 1) % 100 == 0 || i < 5) {
            cout << "Solving case " << (i + 1) << "/" << n << "..." << endl;
        }

        // Solve the case
        auto result = solveCase(target_x, target_y, time_limit, asteroid_x, asteroid_y);
        vector<int> acc_x = result.first;
        vector<int> acc_y = result.second;

        // Write output
        for (size_t j = 0; j < acc_x.size(); j++) {
            if (j > 0) outfile << " ";
            outfile << acc_x[j];
        }
        outfile << endl;

        for (size_t j = 0; j < acc_y.size(); j++) {
            if (j > 0) outfile << " ";
            outfile << acc_y[j];
        }
        outfile << endl;

        // Empty line between cases (except after last case)
        if (i < n - 1) {
            outfile << endl;
        }
    }

    cout << "Done! Output written to: " << output_file << endl;

    infile.close();
    outfile.close();

    return 0;
}