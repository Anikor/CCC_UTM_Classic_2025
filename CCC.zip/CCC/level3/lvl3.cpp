#include <bits/stdc++.h>
using namespace std;

// blocuri pentru pozitii pozitive 1..7, FARA 0 initial (se termina cu 0)
vector<int> blockPos[8];

vector<int> buildSequence(long long target) {
    if (target == 0) return {0};

    bool neg = (target < 0);
    long long P = llabs(target);

    long long k = P / 7;
    long long r = P % 7;

    vector<int> seq;
    seq.push_back(0); // secventa trebuie sa inceapa cu pace 0

    auto addBlock = [&](int d) {
        for (int p : blockPos[d]) {
            seq.push_back(neg ? -p : p);
        }
    };

    for (long long i = 0; i < k; ++i) addBlock(7);
    if (r > 0) addBlock((int)r);

    return seq;
}

// functie optionala de verificare (nu e necesara pentru submit)
pair<long long,long long> simulate(const vector<int>& seq) {
    long long pos = 0, t = 0;
    for (int p : seq) {
        if (p > 0) { pos += 1; t += p; }
        else if (p < 0) { pos -= 1; t += -p; }
        else { t += 1; }
    }
    return {pos, t};
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    // definim blocurile pentru +1..+7 (fara 0 initial)
    blockPos[1] = { 5, 0 };
    blockPos[2] = { 5, 5, 0 };
    blockPos[3] = { 5, 4, 5, 0 };
    blockPos[4] = { 5, 4, 4, 5, 0 };
    blockPos[5] = { 5, 4, 3, 4, 5, 0 };
    blockPos[6] = { 5, 4, 3, 3, 4, 5, 0 };
    blockPos[7] = { 5, 4, 3, 2, 3, 4, 5, 0 };

    int N;
    if (!(cin >> N)) return 0;

    for (int i = 0; i < N; ++i) {
        long long station, limitTime;
        cin >> station >> limitTime;

        vector<int> seq = buildSequence(station);

        // (optional) poti verifica:
        // auto [pos, tim] = simulate(seq);
        // assert(pos == station && tim <= limitTime);

        for (size_t j = 0; j < seq.size(); ++j) {
            if (j) cout << ' ';
            cout << seq[j];
        }
        if (i + 1 < N) cout << '\n';
    }

    return 0;
}
