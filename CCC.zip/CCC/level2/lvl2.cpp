#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;  // numărul de secvențe
    string line;
    getline(cin, line);         // consumăm restul liniei cu N

    for (int seq = 0; seq < N; ++seq) {
        // citim o linie nenulă (în caz că există linii goale)
        do {
            if (!getline(cin, line)) return 0;
        } while (line.empty());

        stringstream ss(line);
        long long p;
        long long pos = 0;   // poziția navei pentru această secvență
        long long time = 0;  // timpul total pentru această secvență

        while (ss >> p) {
            if (p > 0) {
                pos += 1;
                time += p;
            } else if (p < 0) {
                pos -= 1;
                time += -p;   // |p|
            } else { // p == 0
                time += 1;
            }
        }

        cout << pos << ' ' << time;
        if (seq + 1 < N) cout << '\n';
    }

    return 0;
}
