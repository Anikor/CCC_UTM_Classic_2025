#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    // DESCHIDEM FIȘIERELE
    freopen("level1_2_large.in", "r", stdin);      // citire din fișier
    freopen("level1_2_large.out", "w", stdout);    // scriere în fișier

    int N;
    if (!(cin >> N)) return 0;   // numărul de linii (de „drumuri”)

    string line;
    getline(cin, line);          // consumăm restul liniei după N

    for (int i = 0; i < N; ++i) {
        // citim o linie completă cu numere
        if (!getline(cin, line)) break;
        if (line.empty()) {      // dacă prindem o linie goală, mai încercăm o dată
            i--;
            continue;
        }

        long long x, sum = 0;
        istringstream iss(line);
        while (iss >> x) sum += x;

        cout << sum;
        if (i + 1 < N) cout << '\n';
    }

    return 0;
}
